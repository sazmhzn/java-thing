/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginPackage;

/**
 *
 * @author lenovo
 */
public class LoginModel {
    private int adminid;
    private String loginId;
    private String password;

    public LoginModel(int adminid, String password) {
        this.adminid = adminid;
        this.password = password;
    }

    public int getAdminid() {
        return adminid;
    }

    public void setAdminid(int adminid) {
        this.adminid = adminid;
    }

    
    public LoginModel(String loginId, String password) {
        this.loginId = loginId;
        this.password = password;
    }

    public LoginModel(String loginId) {
        this.loginId = loginId;
    }
    
     public void setPassword(String password) {
        this.password = password;
    }
    

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPassword() {
        return password;
    }

   
    
}
