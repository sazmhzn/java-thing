/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package loginPackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
public class LoginCheck extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out = response.getWriter();

        HttpSession s=request.getSession();


            String buttonValue = request.getParameter("button");
            System.out.println(buttonValue);
            int aid;
            String username;
            String password;
            

                  if( buttonValue.equals("teacher") ) {
                       username = request.getParameter("username");
                       password = request.getParameter("password");
                      LoginModel model = new LoginModel(username, password);
                      LoginDao ldao = new LoginDao();
                      
                      
                      if( ldao.checkTeacherLogin(model) ) {
                          System.out.println("Succsfullt checed the tachers login");
                          response.sendRedirect("index.jsp");
                      }
                      
                      
                  } else if(buttonValue.equals("verify")) {
                      System.out.println("You are in verify method");
                      username = request.getParameter("username");
                      
                      s.setAttribute("name",username);
                      
                      LoginModel model = new LoginModel(username);
                      System.out.println("the user is " + model.getLoginId());
                      LoginDao ldao = new LoginDao();
                      
                      if( ldao.forgotPassword(model) ) {
                          System.out.println("Your enail is verified");
                          
                          //Set the session to the user's name
//                          session.setAttribute("varName", username);

                          response.sendRedirect("http://localhost:8080/Attendance_Management_System/forgotPasswordFinal.jsp");
                      }
                      
                      //this will start when the change button is clicked
                  } else if( buttonValue.equals("change") ) {
                      
                      //get the password and confirm password
                      password = request.getParameter("password");
                      String cpassword = request.getParameter("cpassword");
                        
                      
                      //check if the password and the  check password is same
                      if( password.equals(cpassword) ) {
                          
                          //Now ge the session from verify and set it in model
                          username = s.getAttribute("name").toString();
                          LoginModel model = new LoginModel(username, password);
                          model.setPassword(password);
                          //print the login id and password
                          System.out.println(model.getLoginId() + " " + model.getPassword());
                          
                          LoginDao ldao = new LoginDao();
                          ldao.changePassword(model);
                         
                              System.out.println("Your password has been changed");
                              response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminLogin.jsp");
                          
                      } else {
                          out.print("The password does not match");
                      }
                  } else if( buttonValue.equals("admin") ) {
                      aid = Integer.parseInt( request.getParameter("username") ) ;
                      password = request.getParameter("password");
                      
                      s.setAttribute("admin", aid);
                      
                      LoginModel model = new LoginModel(aid, password);
                      
                      System.out.println("username and password: " + model.getAdminid()+ model.getPassword());
                      
                      LoginDao ldao = new LoginDao();
                      
                      if( ldao.checkLogin(model) ) {
                          response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminHome.jsp");
                          
                      }  else {
                            String messege = "Sujectid or Password is invalid";
                            response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminLogin.jsp?messege="+messege);
                        }
                  } else if(buttonValue.equals("login")) {
                      username = request.getParameter("username");
                      password = request.getParameter("password");
                        s.setAttribute("username", username);
                        
                      System.out.println(" the calue create in session is :" + s.getAttribute("username"));
                      System.out.println("You just loged in the login chek servlet method condition");
                      
//                      System.out.println( username + password + " ");
                      LoginModel model = new LoginModel(username, password);
//                      System.out.println("The value in model is : ");
//                      System.out.println(model.getLoginId() + " " + model.getPassword());

                        LoginDao ldao = new LoginDao();
                        
                        if ( ldao.checkTeacherLogin(model) ) {
                            
                            response.sendRedirect("index.jsp");
                            
                        } else {
                            String messege = "Sujectid or Password is invalid";
                            response.sendRedirect("http://localhost:8080/Attendance_Management_System/LoginPage.jsp?messege="+messege);
                        }

                  }

        out.close();

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
