/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginPackage;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class LoginDao {

    private String dburl = "jdbc:mysql://localhost:3306/attendance";
    private String dbuname = "root";
    private String dbpassword = "";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public void loadDriver(String dbDriver) {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);
        } catch (SQLException e) {
        }
        return con;

    }

    public String insert(LoginModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        String result = "Data entered Succesfully";
        String sql = "insert into attendance.loginid values(?,?)";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setString(1, model.getLoginId());
            ps.setString(2, model.getPassword());
            int i = ps.executeUpdate();
            System.out.println(i + "record is stored");
        } catch (SQLException e) {
            result = "Data not entered";
        }
        return result;
    }

    public Boolean checkLogin(LoginModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        String sql = "Select * from admin where aid = ? and password = ?";
  
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            System.out.println("***************** checkLogin() ***************");
            ps.setInt(1, model.getAdminid());
            ps.setString(2, model.getPassword());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;
            }
            rs.close();
            ps.close();

            return false;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
     public Boolean checkTeacherLogin(LoginModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        String sql = "Select * from teacher where username = ? and password = ?";
  
        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, model.getLoginId());
            ps.setString(2, model.getPassword());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;
            }
            rs.close();
            ps.close();

            return false;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public Boolean forgotPassword(LoginModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();

        String checkSql = "Select * from admin where aid = ?";

        try {
            PreparedStatement ps = con.prepareStatement(checkSql);

            ps.setString(1, model.getLoginId());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public void changePassword(LoginModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql = "Update admin set aid = ?, password=? where aid = ?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            //The ! below is to denote the above ?. we are putting avlue in first place
            
             
             ps.setString(1, model.getLoginId());
             ps.setString(2, model.getPassword());
             ps.setString(3, model.getLoginId());
           
            int i = ps.executeUpdate();
           
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
  
    }
}
