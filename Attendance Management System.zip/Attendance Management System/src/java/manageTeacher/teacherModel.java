/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manageTeacher;

/**
 *
 * @author lenovo
 */
public class teacherModel {
    private String subjectid;
     private int tid;
    private String tfname;
    private String tlname;
    private String password;
    private String subject;
    

    public teacherModel( int tid, String tfname, String tlname, String subjectid , String password) {
        this.subjectid = subjectid;
        this.tid = tid;
        this.tfname = tfname;
        this.tlname = tlname;
        this.password = password;
    }

    public teacherModel( int tid, String subject,  String tfname,  String tlname, String subjectid, String password) {
        this.subjectid = subjectid;
        this.tid = tid;
        this.tfname = tfname;
        this.tlname = tlname;
        this.password = password;
        this.subject = subject;
    }

    public teacherModel(int tid) {
        this.tid = tid;
    }

    public teacherModel(String subjectid) {
        this.subjectid = subjectid;
    }
    
    public String getSubjectid() {
        return subjectid;
    }

    public void setSubjectid(String subjectid) {
        this.subjectid = subjectid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public String getTfname() {
        return tfname;
    }

    public void setTfname(String tfname) {
        this.tfname = tfname;
    }

    public String getTlname() {
        return tlname;
    }

    public void setTlname(String tlname) {
        this.tlname = tlname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
