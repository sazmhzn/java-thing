/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manageTeacher;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class TeacherDao {

    private String dburl = "jdbc:mysql://localhost:3306/attendance";
    private String dbuname = "root";
    private String dbpassword = "";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public void loadDriver(String dbDriver) {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    
    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);
        } catch (SQLException e) {
        }
        return con;

    }

    
    /**
     *  This method is used to add a teacher in the database
     * @param model
     * @return true if the query is syccesfull
     */
    public boolean addTeacher(teacherModel model) {

        loadDriver(dbDriver);
        Connection con = getConnection();
        
        System.out.println("entered the addTeacher servlet");
        String sql = " insert into teacher values(?, ?, ?, ?, ?)  ";
        String sql1 = " insert into subject (subjectid) values(?)  ";
        String sql2 = " insert into teach values( ?, ? )  ";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            /**
             * The below code will plcae the value in teh ? above
             */
            ps.setInt(1, model.getTid());
            ps.setString(2, model.getTfname());
            ps.setString(3, model.getTlname());
            ps.setString(4, model.getSubjectid());
            ps.setString(5, model.getPassword());
            
//             PreparedStatement ps1 = con.prepareStatement(sql1);
//            ps1.setString(1, model.getSubjectid());
//          
//            PreparedStatement ps2 = con.prepareStatement(sql2);
//            ps.setString(1, model.getSubjectid());
//            ps.setInt(2, model.getTid());

            
            int i = ps.executeUpdate();
//            int j = ps1.executeUpdate();
//            int k = ps2.executeUpdate();
            System.out.println("The value from the model is set");
            return true;

        } catch (Exception e) {
            
            e.printStackTrace();
        }

        return false;
    }
    
    
    
    public boolean removeTeacher(teacherModel model) {

        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql = " delete from teacher where tid = ? ";
        String sql1 = "delete from teach where teacherid = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            PreparedStatement ps1 = con.prepareStatement(sql1);

            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setInt(1, model.getTid());
            ps1.setInt(1, model.getTid());
            
            System.out.println("\nThe remove query is: " + ps);
            System.out.println("\nThe remove query is: " + ps1);
            
            int i = ps.executeUpdate();
            int j = ps1.executeUpdate();
            
            return true;

        } catch (Exception e) {

        }

        return false;

    }

    public boolean updateteacher(teacherModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();

//        String sql = " update teacher set tid = ?, tfnmae = ?, tlnmae = ?, username = ?, password = ? where tid = ?  ";
    String sql = "update teacher set teacher.tfnmae = ?, teacher.tlnmae = ?, teacher.username = ?, teacher.password = ? where tid = ? ";
//    String sql1 = "update subject set subject = ? where subjectid = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setString(1, model.getTfname());
            ps.setString(2, model.getTlname());
            ps.setString(3, model.getSubjectid());
            ps.setString(4, model.getPassword());
            ps.setInt(5, model.getTid());

//            PreparedStatement ps1 = con.prepareStatement(sql1);
//            ps1.setString(2, model.getSubjectid());
//            ps1.setString(1, model.getSubject());
                        
            ps.executeUpdate();
//            ps1.executeUpdate();
            
            
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
