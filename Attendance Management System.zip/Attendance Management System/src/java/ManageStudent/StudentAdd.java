/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ManageStudent;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
public class StudentAdd extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
//        String roll = request.getParameter("roll");
//        System.out.println(roll +  " is send here");
//        
//        
//        StudentModel model = new StudentModel(roll);
//       
//        
//        studentDao sdao = new studentDao();
//        
//        if (sdao.delete(model)) {
//             response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminAddStudent.jsp");
//        } else {
//            System.out.println("The value is not trure");
//        }
//        
//       
     
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html");
        
        System.out.println("\n ************************* studentAdd servlet ***************************\n");
        PrintWriter out = response.getWriter();

        //store the info in the model
        int roll = Integer.parseInt(request.getParameter("roll"));
        String studentName = request.getParameter("studentName");
        String semester = request.getParameter("semester");
        String section = request.getParameter("section");
        System.out.println(studentName);
        System.out.println(semester);
        System.out.println(section);
        
        System.out.println("The values are: "  + roll + studentName + semester + section  );

        StudentModel model = new StudentModel(roll, studentName, semester, section);
        
        String button = request.getParameter("button");
        
        System.out.println(model.getName() + " " + model.getSection() + " " + model.getSemester() + " " +  model.getRoll());
        
        studentDao sdao = new studentDao();
        System.out.println("The button valeu iin the servlet is: " + button);
        if (button.equals("add")) {
            if (sdao.insert(model)) {
                System.out.println("Added");
                response.sendRedirect("adminAddStudent.jsp");
                
            }
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
