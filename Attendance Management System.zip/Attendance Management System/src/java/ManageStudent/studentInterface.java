/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ManageStudent;

/**
 *
 * @author lenovo
 */
public interface studentInterface {

    public Boolean insert(StudentModel model);

    public Boolean update(StudentModel model, int old_roll);

    public Boolean delete(StudentModel model);

    public boolean search(StudentModel model);

}
