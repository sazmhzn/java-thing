/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageStudent;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class studentDao implements studentInterface {

    private String dburl = "jdbc:mysql://localhost:3306/attendance";
    private String dbuname = "root";
    private String dbpassword = "";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public void loadDriver(String dbDriver) {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);

        } catch (SQLException e) {
        }
        return con;

    }

    /**
     *
     * @param model
     * @return
     */
    @Override
    public Boolean insert(StudentModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result = true;
        String sql = "insert into student values( ?, ?, ?, ?, now() )";
        String sql1 = " insert into status (attid, roll, attendance, attendance_date, attendance_count ) values (?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);

            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setInt(1, model.getRoll());
            ps.setString(2, model.getName());
            ps.setString(3, model.getSemester());
            ps.setString(4, model.getSection());

            PreparedStatement ps1 = con.prepareStatement(sql1);
            ps1.setInt(1, model.getRoll());
            ps1.setInt(2, model.getRoll());
            ps1.setInt(3, 0);
            ps1.setDate(4, java.sql.Date.valueOf(java.time.LocalDate.now()));
            ps1.setInt(5, 0);

            int i = ps.executeUpdate();
            int j = ps1.executeUpdate();
            System.out.println(i + "record is stored");

        } catch (SQLException e) {
            result = false;

        }
        return result;
    }

    /**
     *
     * @param model
     * @param old_roll
     * @return
     */
    @Override
    public Boolean update(StudentModel model, int old_roll) {
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result = false;
        System.out.println("\n****************** Student Update servlet ****************8");
        String sql = "update student set roll = ?, sname = ?, semester = ?, section = ? where roll = ?";
        String sql1 = "update present_Attendance set roll = ? where roll = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);

            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setInt(1, model.getRoll());
            ps.setString(2, model.getName());
            ps.setString(3, model.getSemester());
            ps.setString(4, model.getSection());
            ps.setInt(5, old_roll);

            PreparedStatement ps1 = con.prepareStatement(sql1);
            ps1.setInt(1, model.getRoll());
            ps1.setInt(2, old_roll);

             int j = ps1.executeUpdate();
            int i = ps.executeUpdate();

            if (i == 1 && j == 1) {
                result = true;
            }

            System.out.println(i + "record is updated");

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return result;
    }

    /**
     *
     * @param model
     * @return
     */
    @Override
    public Boolean delete(StudentModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result = true;

        System.out.println("\n*************** delete() ****************");

        String sql = "delete from student where roll = ?;";
//         String sql1 = "delete from present_Attendance where roll=?;";
        try {
            System.out.println("You are in the try clause");
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, model.getRoll());

            int i = ps.executeUpdate();

            if (i == 1) {
                System.out.println("The query executed: " + ps);
                result = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();

        }
        System.out.println(result);
        return result;
    }

    /**
     *
     * @param model
     * @return true if the query is executed
     */
    @Override
    public boolean search(StudentModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result = true;
        String sql = "select * from student where sname = ? ";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            //The ! below is to denote the above ?. we are putting avlue in first place
            ps.setString(1, model.getName());

            int i = ps.executeUpdate();
            System.out.println("The value isi executed " + i);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                result = true;
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            e.printStackTrace();
            result = false;

        }
        return result;
    }

}
