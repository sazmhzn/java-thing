/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ManageStudent;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author lenovo
 */
public class StudentUpdate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String id = request.getParameter("id");

        System.out.println("The clicked button is: " + id);

        response.sendRedirect("adminStudentUpdate.jsp?roll=" + id);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

        int old_roll = Integer.parseInt( request.getParameter("button") ) ;
        int roll = Integer.parseInt(request.getParameter("roll"));
        String studentName = request.getParameter("studentName");
        String semester = request.getParameter("semester");
        String section = request.getParameter("section");
        
        System.out.println("\n************** StudentUpdate servlet *****************");
        
        StudentModel model = new StudentModel( roll, studentName, semester, section );
        System.out.println(" oldrol: " + old_roll + " \n new Roll: " + roll + " \nname: " + studentName+ " \n semester: " + semester + " \nsection: " + section);
        studentDao sdao = new studentDao();
        
        if(sdao.update(model, old_roll)) {
            System.out.println("The student detail is updated");
            response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminAddStudent.jsp");
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
