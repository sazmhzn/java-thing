/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageStudent;

/**
 *
 * @author lenovo
 */
public class StudentModel {
    public int roll;
    public String name;
    public String semester;
    public String section;

    public StudentModel(int roll, String name, String semester, String section) {
        this.roll = roll;
        this.name = name;
        this.semester = semester;
        this.section = section;
    }
    

    public StudentModel(String name, String semester, String section) {
        this.name = name;
        this.semester = semester;
        this.section = section;
    }

    public StudentModel(int roll) {
        this.roll = roll;
    }

    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }
    

    public StudentModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
    
    
    
}
