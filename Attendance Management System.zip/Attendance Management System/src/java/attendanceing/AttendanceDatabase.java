/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package attendanceing;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
public class AttendanceDatabase extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        try ( PrintWriter out = response.getWriter()) {
            
            HttpSession ses = request.getSession();
  
            String s[] = request.getParameterValues("id");
            String subject = request.getParameter("button");
            System.out.println("\n****************** You are in AttendanceDatabse Servlet ***************** ");
        
        //Object initializaation for attendance database
        attendanceDao adao = new attendanceDao();
        
            if (s != null && s.length != 0) {

                for (int i = 0; i < s.length; i++) {
                    String fname = s[i];
                    AttendanceModel model  = new AttendanceModel(fname, subject);
                    System.out.println("\nValue sent are: " + fname);
                    Boolean result = adao.presentAttendance(model);
                    System.out.println(result + " completed!!");
                }
                AttendanceModel model1 = new AttendanceModel(subject);
               model1.setName(subject);
                adao.absentAttendance(model1);
                
                
                
                response.sendRedirect("http://localhost:8080/Attendance_Management_System/AttendanceList.jsp");
            } else {
                response.sendRedirect("index.jsp");
            }
        } catch (Exception e) {
            System.out.println("Chalena");
            
//            e.printStackTrace();
            response.sendRedirect("https://stackoverflow.com/questions/tagged/" + e);

        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
