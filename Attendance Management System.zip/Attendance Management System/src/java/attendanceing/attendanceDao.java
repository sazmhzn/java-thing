/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package attendanceing;

import static java.lang.System.out;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */
public class attendanceDao {

    private String dburl = "jdbc:mysql://localhost:3306/attendance";
    private String dbuname = "root";
    private String dbpassword = "";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public void loadDriver(String dbDriver) {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);
        } catch (SQLException e) {
        }
        return con;

    }

    /* This will make the student present */
    public boolean attendaceUpdate(AttendanceModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result = false;
        String sql = "update status set attendance = true, attendance_count = attendance_count + 1 where roll = ?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);

            //The ! below is to denote the above ?. we are putting avlue in first place
            //ps.setString(1, model.getLoginId());
            ps.setString(1, model.getName());

            int i = ps.executeUpdate();
            
            if( i == 1) { 
                result = true;
            }

        } catch (SQLException e) {
            
            e.printStackTrace();
        }
        return result;
    }

    public void absentStudent() {
        loadDriver(dbDriver);
        Connection con = getConnection();
        Statement stmt;
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from status where attendance = 0");

            while (rs.next()) {
                String name = rs.getString(2);
                AttendanceModel model = new AttendanceModel(name);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public String refresh(AttendanceModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();
        String result = "Table updated Succesfully";
        
//        String sql = "update status set attendance = false, attendance_count = 0 where roll = ?";
String sql = "delete from present_Attendance where att_date = current_Date";
String sql1 = "delete from absent_Attendance where att_date = current_Date";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            PreparedStatement ps1 = con.prepareStatement(sql1);
            
            int i = ps.executeUpdate();
             int j = ps1.executeUpdate();
            
        } catch (SQLException e) {
            result = "Table not updated";
        }
        return result;
    }

//    new attendance system ocde
    /**
     *
     * @param model
     * @return
     */
    public Boolean presentAttendance(AttendanceModel model) {
        //when someone calss the insert function the driver is loaded 
        // we get the connection
        //we put the things in the databse;
        loadDriver(dbDriver);
        Connection con = getConnection();
        Boolean result;
        String sql = "insert into present_Attendance values(now(), ?, ?)";
        String sql1 = "select * from present_Attendance where roll = " + model.getRoll() + " and att_Date = CURRENT_DATE";
        try {

            System.out.println("\n************** Your are in presentAttendance() ***********************");
            System.out.println(" Roll:  " + model.getRoll());
            System.out.println("Name:   " + model.getName());

            PreparedStatement ps1 = con.prepareStatement(sql1);

            ResultSet rs;

            rs = ps1.executeQuery();
            //loop througn the table
            int count = 0;
//get the value of student of today
            while (rs.next()) {
                count++;
            }

            
//            if there are no tables
            if (count == 0) {

                PreparedStatement ps = con.prepareStatement(sql);

                ps.setString(1, model.getRoll());
                ps.setString(2, model.getName());
                int i = ps.executeUpdate();
                return true;
//                }

            } else {
                System.out.println("The date shown by database is " + rs.getDate(1));
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                LocalDateTime now = LocalDateTime.now();
                out.println("The date showin by java is = " + dtf.format(now).toString());

                if (!rs.getDate("att_Date").equals(dtf.format(now).toString())) {

                    PreparedStatement ps = con.prepareStatement(sql);

                    ps.setString(1, model.getRoll());
                    ps.setString(2, model.getName());
                    int i = ps.executeUpdate();
                    
                    if( i == 1 ) {
                        return true;
                    }
                    
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean absentAttendance(AttendanceModel model1) {
        loadDriver(dbDriver);
        Connection con = getConnection();
//        String sql1 = "SELECT * FROM student s LEFT JOIN present_attendance ps ON s.roll = ps.roll WHERE att_Date IS null;";
        String sql1 = "SELECT s.roll, ps.att_Date, ps.subjectid, s.sname FROM present_attendance ps RIGHT JOIN student s ON ps.roll = s.roll WHERE s.roll NOT IN( SELECT roll FROM present_attendance WHERE att_Date = CURRENT_DATE ) AND subjectid = 'ccp313' OR subjectid IS NULL GROUP BY ps.roll;;";
        String sql = "insert into absent_Attendance values(?, ?, now(), null)";
        System.out.println("\n***************** You are in the absent Attendance () ***************");
        try{

            //this will check for the studnet whose attendace have not been done till now(tourist whose visa is not granted)
            PreparedStatement ps1 = con.prepareStatement(sql1);
            ResultSet rs = ps1.executeQuery();
            
            //this is the visa checking; checking for null att_Date in present_attendance data and student join
            while( rs.next() ) {
                System.out.println();
               System.out.println("\nThe row:" + rs.getInt("roll") + " " + rs.getString("sname") + " "  + model1.getName());
                 PreparedStatement ps = con.prepareStatement(sql);
                
                 ps.setInt(1, rs.getInt("roll"));
                 ps.setString(2, model1.getName());
                  System.out.println("\nThe running query is " + ps);
                
                  
                  int i = ps.executeUpdate();
           
            }

           
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return false;

    }

}
