/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ManageSubject;

/**
 *
 * @author lenovo
 */
public interface subjectInterface{

    SubjectModel model = new SubjectModel();
    
    public boolean addSubject(SubjectModel model);
    
    public boolean addSemester(SubjectModel model);
    
    public boolean updateSubject(SubjectModel model);
    
    public boolean removeSubject(SubjectModel model);

}
