/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageSubject;

/**
 *
 * @author lenovo
 */
public class SubjectParent {
    private String subjectid;
    private String subject;

    public SubjectParent() {
        
    }
    
    

    public SubjectParent(String subjectid, String subject) {
        this.subjectid = subjectid;
        this.subject = subject;
    }

    public SubjectParent(String subjectid) {
        this.subjectid = subjectid;
    }
    
    public String getSubjectid() {
        return subjectid;
    }

    public void setSubjectid(String subjectid) {
        this.subjectid = subjectid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    
    
}
