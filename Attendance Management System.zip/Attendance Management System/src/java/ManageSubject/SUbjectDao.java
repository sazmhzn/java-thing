/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageSubject;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class SUbjectDao implements subjectInterface {

    private String dburl = "jdbc:mysql://localhost:3306/attendance";
    private String dbuname = "root";
    private String dbpassword = "";
    private String dbDriver = "com.mysql.cj.jdbc.Driver";

    public void loadDriver(String dbDriver) {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(dburl, dbuname, dbpassword);
        } catch (SQLException e) {
        }
        return con;

    }

    /**
     * This method is used to add a teacher in the database
     *
     * @param model
     * @return true if the query is syccesfull
     */
    @Override
    public boolean addSubject(SubjectModel model) {

        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql = " insert into subject values(?, ?) ";

        try {
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, model.getSubjectid());
            ps.setString(2, model.getSubject());

            int i = ps.executeUpdate();

            System.out.println("The value from the model is set");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;

    }

    @Override
    public boolean addSemester(SubjectModel model) {

        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql1 = "insert into college values(?, ?)";
        String sql2 = "insert into teach values(?, ?)";

        try {

            PreparedStatement ps1 = con.prepareStatement(sql1);
            ps1.setInt(1, Integer.parseInt(model.getSemester()));
            ps1.setString(2, model.getSubjectid());

            PreparedStatement ps = con.prepareStatement(sql2);
            ps.setString(1, model.getSubjectid());
            ps.setInt(2, model.getTid());

            int k = ps.executeUpdate();
            int j = ps1.executeUpdate();

            System.out.println("The value from the model is set");

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    @Override
    public boolean updateSubject(SubjectModel model) {
        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql = "update subject set subjectid = ?, subject = ? where subjectid = ?";
        String sql1 = "update college set sid = ?, subjectid = ? where subjectid = ?";
        String sql2 = "update teach set subjectid = ? , teacherid = ? where subjectid = ?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, model.getSubjectid());
            ps.setString(2, model.getSubject());
            ps.setString(3, model.getSubjectid());

            PreparedStatement ps1 = con.prepareStatement(sql1);
            ps1.setInt(1, Integer.parseInt(model.getSemester()));
            ps1.setString(2, model.getSubjectid());
            ps1.setString(3, model.getSubjectid());

            PreparedStatement ps2 = con.prepareStatement(sql2);
            ps2.setString(1, model.getSubjectid());
            ps2.setInt(2, model.getTid());
            ps2.setString(3, model.getSubjectid());

            int k = ps.executeUpdate();
            System.out.println("The task is completed " + k);
            int j = ps1.executeUpdate();
            System.out.println("The task is completed " + j);
            int i = ps2.executeUpdate();
            System.out.println("The task is completed " + i);
            
            if (i == 1 && j == 1 && k == 1) {
                System.out.println("The value from the model is add");
                return true;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean removeSubject(SubjectModel model) {

        System.out.println("\n************** removeSubject() ****************");
        loadDriver(dbDriver);
        Connection con = getConnection();

        String sql = " delete from subject where subjectid = ?";
        String sql1 = "delete from teach where subjectid = ?";
        String sql2 = "delete from college where subjectid = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, model.getSubjectid());

            PreparedStatement ps1 = con.prepareStatement(sql1);
            ps1.setString(1, model.getSubjectid());

            PreparedStatement ps2 = con.prepareStatement(sql2);
            ps2.setString(1, model.getSubjectid());

             int j = ps.executeUpdate();
            System.out.println("The task is completed " + j);
            
            int i = ps1.executeUpdate();
            System.out.println("The task is completed " + i);
           
            int k = ps2.executeUpdate();
            System.out.println("The task is completed " + k);

            if (i == 1 && j == 1 && k == 1) {
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
