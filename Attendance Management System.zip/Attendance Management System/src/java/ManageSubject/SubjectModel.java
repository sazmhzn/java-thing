/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageSubject;

/**
 *
 * @author lenovo
 */
public class SubjectModel extends SubjectParent{
    private String semester;
    private int tid;

    public SubjectModel() {
        super();
    }
    
    public SubjectModel( String subjectid, String subject ) {
        super( subjectid, subject );
    }

    public SubjectModel( String subjectid, String subject, String semester) {
        super(subjectid, subject);
        this.semester = semester;
    }
    
    public SubjectModel( String subjectid, String subject, String semester, int tid) {
        super(subjectid, subject);
        this.semester = semester;
        this.tid = tid;
    } 
    
    public SubjectModel(String subjectid) {
        super(subjectid);
        
    }

     public void setSemester(String semester) {
        this.semester = semester;
    }
     
    public String getSemester() {
        return semester;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }
}
