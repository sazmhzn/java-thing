/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ManageSubject;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author lenovo
 */
public class addSubject extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String code = request.getParameter("subjectid");
        String subject = request.getParameter("subjectName");
        String semester = request.getParameter("semester");
        int tid = Integer.parseInt(request.getParameter("teacherid"));

        String button = request.getParameter("button");

        SubjectModel model = new SubjectModel(code, subject, semester, tid);

        System.out.println("\n**************** addSubejct *****************");
        System.out.println("\nSubject id:" + code + "\nSubejct: " + subject + "\nsemester: " + semester + "\nteacherid: " + tid);
        System.out.println("\nSubject: " + model.getSubject() + " \nSubjet code:" + model.getSubjectid() + " \nSemester:" + model.getSemester() + " \nTeacherid: " + model.getTid());

        SUbjectDao sudao = new SUbjectDao();

        if (button.equals("add")) {
            if (sudao.addSubject(model)) {
                if (sudao.addSemester(model)) {
                    response.sendRedirect("http://localhost:8080/Attendance_Management_System/adminAddSubject.jsp");
                }
            }
        } else if ( button.equals("update") ) {
            if( sudao.updateSubject(model) ) {
                response.sendRedirect( "http://localhost:8080/Attendance_Management_System/adminAddSubject.jsp" );
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
